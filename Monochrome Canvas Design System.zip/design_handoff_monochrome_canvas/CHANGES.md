# CHANGES.md — per-screen diff guide

Every edit listed here is **style-only**. No reducers, no state, no props
changed. If you find yourself rewriting behavior, stop — you've gone too far.

Before you start: confirm `theme.js` and `useTheme.jsx` have been replaced
(see README). Most of the visual transition happens there automatically.

Files below are listed in implementation order — easiest first.

---

## 1 · `src/index.css` (or `main.css`)

**Add** at the top:

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=JetBrains+Mono:wght@400;500;700&display=swap');

:root {
  --font-sans: 'Inter', 'Pretendard', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', 'SF Mono', Menlo, monospace;
}
body {
  font-family: var(--font-sans);
  font-weight: 340;
  letter-spacing: -0.14px;
}
*:focus-visible { outline: dashed 2px currentColor; outline-offset: 2px; }
```

**Keep** the existing Pretendard import for Korean glyph fallback.

---

## 2 · `src/components/auth/LoginScreen.jsx`

Structural changes only.

### Replace hero copy

Before — boxed card with centered title:
```jsx
<div style={{ ...s.card, textAlign: "center" }}>
  <h1 style={{ fontSize: 24, fontWeight: 800 }}>⚽ 경기 기록</h1>
  <p>로그인하세요</p>
</div>
```

After — left-aligned editorial headline:
```jsx
<div style={{ padding: "32px 24px 48px" }}>
  <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: 0.6,
                opacity: 0.5, marginBottom: 10, textTransform: "uppercase" }}>
    Master FC — V2
  </div>
  <h1 style={{ fontSize: 48, fontWeight: 400, letterSpacing: "-1.8px",
               lineHeight: 1, margin: 0 }}>
    Record every <span style={{ fontStyle: "italic", fontWeight: 450 }}>match.</span>
  </h1>
  <p style={{ fontSize: 16, color: C.gray, marginTop: 12, maxWidth: 280 }}>
    골·어시·실점을 정확히. 팀의 모든 기록은 여기서.
  </p>
</div>
```

### Inputs — underline instead of boxed

`s.input` in the new theme is already `border: none; border-bottom: 1.5px solid var(--fg);`
so existing `<input style={s.input} />` callsites need **no change**.

### CTA

Existing `<button style={s.btnFull(C.accent, C.bg)}>로그인</button>` auto-becomes
a black pill. Add trailing arrow icon if desired:

```jsx
<button style={s.btnFull(C.accent, C.bg)}>
  로그인 <ArrowIcon />
</button>
```

---

## 3 · `src/components/home/HomeScreen.jsx`

### Team card — the only visible identity

Before: card with team color as left border accent:
```jsx
<div style={{ ...s.teamCard(team.colorIdx), background: TEAM_COLORS[team.colorIdx].bg }}>
  {team.name}
</div>
```

After: **current team = solid black**, other teams = white+border, team
color as an 12px dot:
```jsx
<button style={{
  width: "100%", textAlign: "left",
  background: team.isCurrent ? C.white : C.card,
  color: team.isCurrent ? C.bg : C.white,
  border: team.isCurrent ? "none" : `1px solid ${C.borderColor}`,
  borderRadius: 16, padding: "18px 20px", marginBottom: 10, cursor: "pointer",
}}>
  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
    <span style={{ width: 12, height: 12, borderRadius: "50%",
                   background: TEAM_COLORS[team.colorIdx].bg }} />
    <span style={{ fontSize: 18, fontWeight: 540 }}>{team.name}</span>
  </div>
</button>
```

### "팀 추가하기" — dashed affordance

```jsx
<button style={{
  width: "100%", background: "transparent",
  border: `1.5px dashed ${C.grayDark}`, borderRadius: 16,
  padding: 22, display: "flex", justifyContent: "center", gap: 8,
}}>
  + 팀 추가하기
</button>
```

### Greeting

Replace any "환영합니다" boxed header with an editorial headline:
```jsx
<h1 style={{ fontSize: 40, fontWeight: 400, letterSpacing: "-1.2px", lineHeight: 1.05 }}>
  안녕, <span style={{ fontStyle: "italic", fontWeight: 450 }}>{user.name}</span>.
</h1>
```

---

## 4 · `src/components/game/CourtRecorder.jsx` (main RecordScreen)

### Scoreboard

Replace the existing score row with `s.scoreboard` (already remapped to
monumental 56px tabular numerals). Winning side stays full-opacity, losing
side drops to 38%:

```jsx
<div style={s.scoreboard}>
  <span style={{ opacity: homeScore < awayScore ? 0.38 : 1 }}>{homeScore}</span>
  <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, opacity: 0.4,
                 alignSelf: "flex-end", paddingBottom: 10 }}>VS</span>
  <span style={{ opacity: awayScore < homeScore ? 0.38 : 1 }}>{awayScore}</span>
</div>
```

### Player rows — three-part layout

`[GK toggle (34px circle)]  [Name pill (flex 1)]  [Goal circle (34px)]`

```jsx
<div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 6 }}>
  <button onClick={toggleGk} style={{
    width: 34, height: 34, borderRadius: "50%",
    background: isGk ? C.white : "transparent",
    color:      isGk ? C.bg : C.grayDark,
    border:     isGk ? "none" : `1.2px dashed ${C.grayDarker}`,
    fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: 0.6,
  }}>GK</button>

  <div style={{ flex: 1, padding: "9px 12px", borderRadius: 50,
                background: C.cardLight, textAlign: "center",
                fontSize: 14, fontWeight: 480 }}>
    {player.name}
  </div>

  <button onClick={openGoalModal} style={{
    width: 34, height: 34, borderRadius: "50%",
    background: C.white, color: C.bg, border: "none",
  }}>⚽</button>
</div>
```

### "+ 용병 추가" — dashed orange pill

```jsx
<button style={{
  width: "100%", background: "transparent",
  border: `1.5px dashed ${C.grayDark}`, borderRadius: 50,
  padding: "9px 10px",
  fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: 0.6,
  color: C.orange,
}}>+ MERC</button>
```

### Voice record

Keep existing logic. Restyle the press-and-hold button:
```jsx
<button style={{
  width: "100%", padding: "14px 20px", borderRadius: 50,
  background: isListening ? "transparent" : C.white,
  color:      isListening ? C.white       : C.bg,
  border:     isListening ? `1.5px dashed ${C.white}` : "none",
  fontWeight: 540,
}}>🎤 {isListening ? '듣는 중…' : '꾹 눌러서 음성으로 기록'}</button>
```

---

## 5 · `src/components/game/EventLog.jsx`

Two edits:

1. Replace the emoji dot with a real colored dot:
```jsx
<span style={{ width: 8, height: 8, borderRadius: 8,
               background: e.type === "owngoal" ? C.red : C.green }} />
```
   (or keep ⚽/🔴 if time-constrained — the surrounding chrome already looks clean)

2. Dashed divider between rows — already delivered by `s.eventLog`
   (1px solid borderColor) or swap to:
```jsx
borderBottom: `1px dashed ${C.grayDarker}`,
```

Add a mono minute label at the left:
```jsx
<span style={{ fontFamily: "var(--font-mono)", fontSize: 10,
               opacity: 0.45, width: 36 }}>{e.min}</span>
```

---

## 6 · `src/components/game/GoalModal` (the inline modal inside EventLog/CourtRecorder)

Convert the modal into a **bottom sheet**:

```jsx
<div style={{ position: "fixed", inset: 0, zIndex: 50,
              background: C.overlay, backdropFilter: "blur(6px)",
              display: "flex", alignItems: "flex-end" }}>
  <div style={{ background: C.card, width: "100%",
                borderTopLeftRadius: 24, borderTopRightRadius: 24,
                padding: "20px 22px 28px" }}>
    <div style={{ width: 44, height: 4, background: C.grayDarker,
                  borderRadius: 2, margin: "0 auto 18px" }} />
    {/* handle bar + content */}
  </div>
</div>
```

Teammate pills (4-up grid):
```jsx
<div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
  {teammates.map(p => (
    <button key={p} style={{
      padding: "14px 12px", borderRadius: 50,
      background: C.cardLight, border: "none",
      fontSize: 15, fontWeight: 480,
    }}>{p}</button>
  ))}
</div>
```

"자책골" = dashed red pill, "어시 없음" = glass pill.

---

## 7 · `src/components/dashboard/PlayerCardTab.jsx` (Stats)

### Tabs

Already remapped — `s.tab(active)` is now a pill with dashed border when inactive.

### Top-3 block — monumental numerals

```jsx
{sorted.slice(0, 3).map((p, i) => (
  <div key={p.id} style={{
    display: "flex", alignItems: "baseline", gap: 14,
    padding: "18px 0", borderBottom: `1px dashed ${C.grayDarker}`,
  }}>
    <div style={{ width: 40, textAlign: "right",
                  fontSize: 36, fontWeight: 400, letterSpacing: "-1.4px",
                  fontVariantNumeric: "tabular-nums",
                  color: i === 0 ? C.white : C.grayDark }}>
      {i + 1}
    </div>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 22, fontWeight: 540 }}>{p.name}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 9,
                    color: C.gray, marginTop: 4 }}>
        {p.plays} PLAYED · {p.wins}W
      </div>
    </div>
    <div style={{ fontSize: 32, fontWeight: 480, letterSpacing: "-1px",
                  fontVariantNumeric: "tabular-nums" }}>
      {p[key]}
    </div>
  </div>
))}
```

### Distribution bar chart (optional, high-impact)

See prototype's `StatsScreen` — a horizontal bar per player, dashed baseline,
filled bar in solid black. ~30 min to port.

---

## 8 · Bottom nav / tab bar

In `App.jsx` or wherever the bottom nav lives, each tab label becomes:

```jsx
<button style={{
  flex: 1, display: "flex", flexDirection: "column",
  alignItems: "center", gap: 4, background: "transparent",
  opacity: isActive ? 1 : 0.42,
}}>
  <TabIcon />
  <span style={{
    fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: 0.8,
    textTransform: "uppercase",
    borderBottom: isActive ? `1.5px dashed ${C.white}` : "1.5px dashed transparent",
    paddingBottom: 2,
  }}>{label}</span>
</button>
```

---

## 9 · Things you can skip first pass

- Swapping emoji for SVG icons (defer — chrome already reads as the new system)
- Dark-mode polish (the tokens are ready; verify later)
- Team standing table styling (inherits from `s.td` which is already updated)

## Done-when

- `theme.js` + `useTheme.jsx` swapped, app still runs
- LoginScreen + HomeScreen visually match prototype
- CourtRecorder player rows match (GK circle + name pill + goal circle)
- EventLog rows match (dot + name + meta)
- Tab bar uses dashed underline for active tab
- Focus visible is dashed 2px on every interactive element
- Korean text still renders (Pretendard fallback present)
- Dark-mode toggle still works

Ship it.
